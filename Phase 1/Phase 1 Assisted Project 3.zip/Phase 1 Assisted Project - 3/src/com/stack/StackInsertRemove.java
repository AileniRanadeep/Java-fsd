package com.stack;

import java.util.Stack;

public class StackInsertRemove {
	
	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();
	        
		stack.push(42);
		stack.push(23);
		stack.push(18);
	        
		System.out.println("Stack: " + stack);
	        
	       
		int removedElement = stack.pop();
		System.out.println("Removed element: " + removedElement);
	        
		System.out.println("Stack after Removed: " + stack);
	        
	        
		int topElement = stack.peek();
		System.out.println("Top element: " + topElement);
	}
}

