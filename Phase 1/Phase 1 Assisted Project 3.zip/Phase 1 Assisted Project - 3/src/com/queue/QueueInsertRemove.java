package com.queue;

import java.util.LinkedList;
import java.util.Queue;

public class QueueInsertRemove {
	    public static void main(String[] args) {
	        Queue<String> cityQueue = new LinkedList<>();
	      
	        cityQueue.offer("Japan");
	        cityQueue.offer("China");
	        cityQueue.offer("Delhi");
	        
	        System.out.println("City Queue: " + cityQueue);
	       
	        String removedCity = cityQueue.poll();
	        System.out.println("Dequeued city: " + removedCity);
	        
	        System.out.println("City Queue after dequeue: " + cityQueue);
	       
	        cityQueue.offer("India");
	        System.out.println("City Queue after enqueue: " + cityQueue);
	        
	       
	        String frontCity = cityQueue.peek();
	        System.out.println("Front city: " + frontCity);
	    }
	}

