package com.deletesinglinkedlist;

import java.util.LinkedList;

public class DeletingFirstElement {
	public static void main(String args[]) {
		LinkedList<Integer> k = new LinkedList<>();
		k.add(421);
		k.add(422);
		k.add(420);
		k.add(444);
		k.add(4223);
		k.add(4567);

		System.out.println("Original linked list "+k);
		k.remove(0);
		System.out.println("After removing the very first element "+k);
	}
}

