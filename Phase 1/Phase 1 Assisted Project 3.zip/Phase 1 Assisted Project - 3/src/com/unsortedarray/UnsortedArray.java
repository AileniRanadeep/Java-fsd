package com.unsortedarray;
/*
import java.util.Arrays;
import java.util.HashSet;

public class UnsortedArray {
	public static int FourthSmallest(int[] arr) {
		HashSet<Integer> set = new HashSet<>();
        for (int num : arr) {
            set.add(num);
        }
     // Convert the set back to an array
        int[] Arr = new int[set.size()];
        int i = 0;
        for (int num : set) {
           Arr[i++] = num;
        }
        Arrays.sort(Arr);
        return Arr[3];
    }
	
	public static void main(String[] args) {
		int array[] = {4,1,3,4,15,9,14};
		int SmallestNumber = FourthSmallest(array);
		System.out.println("the Fourthsmallest Element :" +SmallestNumber);
		}
} */


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class UnsortedArray {

    public static void main(String[] args) {
        ArrayList<Integer> num = new ArrayList<>(Arrays.asList(13,52,16,7,90,24,56));
        Set<Integer> num1 = new HashSet<>(num);
        ArrayList<Integer> List = new ArrayList<>(num1);

        Collections.sort(List);
        int position = 3;
        if (List.size() >= 4) {
            System.out.println("The fourth smallest element is: " + List.get(position));
        } else {
            System.out.println("There are less than 4 unique elements in the list.");
        }
    }
}

