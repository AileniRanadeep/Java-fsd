package getpostmethod;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public MyServlet() {
        super();
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String data = request.getParameter("data");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h2>GET Request Data: " + data + "</h2>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String data = request.getParameter("data");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h2>POST Request Data: " + data + "</h2>");
	}
}
