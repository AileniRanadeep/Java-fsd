package cookiesDemo;


import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookiesServlets
 */
public class CookiesServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public CookiesServlets() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String usercookivalue = request.getParameter("cookiname");
		

		PrintWriter out = response.getWriter();
		boolean result = false;
			
		if(result == false) {
			Cookie ad = new Cookie("boma" ,""+usercookivalue);
			response.addCookie(ad);
			out.println("cookie added");
		} 
	}

}
