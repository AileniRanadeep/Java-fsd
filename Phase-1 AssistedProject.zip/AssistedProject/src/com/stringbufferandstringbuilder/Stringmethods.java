package com.stringbufferandstringbuilder;

public class Stringmethods {

	public static void main(String[] args) {
		
		
		
		// 	StringBuilder	
		StringBuilder sb = new StringBuilder("hello");
		System.out.println("sb = "+sb);
		sb.append(" world");
		System.out.println("sb = "+sb);
		sb.append(" testing");
		System.out.println("sb = "+sb);
		sb.reverse();
		System.out.println("sb = "+sb);
		
		// StringBuffer
		StringBuffer sb1 = new StringBuffer("A");
		StringBuffer sb2 = new StringBuffer("A!");
		System.out.println(sb1.toString());
		System.out.println(sb2.toString());
		System.out.println(sb1.hashCode());
		System.out.println(sb2.hashCode());
		System.out.println(sb1.equals(sb2));
		
	}

}
