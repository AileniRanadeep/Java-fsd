package com.collections;
import java.util.*;


public class Collections {
	public static void main(String[] args) {
		
		System.out.println("ArrayList");
		ArrayList<String> animals=new ArrayList<String>();   
	      animals.add("Tiger");//
	      animals.add("Lion");    	   
	      System.out.println(animals); 
	      
	      
		//creating vector
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vec = new Vector<Integer>();
	      vec.addElement(125); 
	      vec.addElement(490); 
	      vec.addElement(75);
	      System.out.println(vec);
	      
	      
		
		//creating linkedlist
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("Sita");  
	      names.add("Ram");  	      
	      Iterator<String> itr=names.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next()); 	       
	       
	       
	       //creating linkedhashset
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(11);  
	       set2.add(83);  
	       set2.add(2);
	       set2.add(54);	       
	       System.out.println(set2);
	       
	       
	     //creating hashset
		  System.out.println("\n");
		  System.out.println("HashSet");
		  HashSet<Integer> set=new HashSet<Integer>();  
		  set.add(130);  
		  set.add(403);  
		  set.add(340);
		  set.add(200);
		  System.out.println(set);
	       
	       
	       
	      	} 
	     }  

		
	}
