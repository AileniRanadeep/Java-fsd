package com.classinnerclass;

public class Outerclass {

	private int outerclass = 100;
	
	// inner class
	public class Innerclass{
		public void test() {
			System.out.println("Inner class method is called");
			System.out.println("Executing inner class test method");
			System.out.println("Outer class = " +outerclass);
		}
	}
	public void callInnerClass() {
		Innerclass inner = new Innerclass();
        inner.test();
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outerclass outer = new Outerclass();
        outer.callInnerClass();

	}
}
