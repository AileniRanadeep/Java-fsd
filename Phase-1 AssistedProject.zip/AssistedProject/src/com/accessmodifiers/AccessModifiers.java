package com.accessmodifiers;


// Default access modifiers
class defAccessSpecifier { 
	 void displaying(int f)  { 
		 System.out.println("You are using defalut access specifier"); 
	     System.out.println(f);
	 }

	 void displaying(float z) {
		// TODO Auto-generated method stub 
		System.out.println(z);
	} 
}


// Private access modifiers
class PrivAccessSpecifier {
	private void display() { 
		System.out.println("You are using private access specifier"); 
	}
}


// public access modifiers
class PubliAccessSpecifier {
	public void sample()  { 
		 System.out.println("You are using public access specifier");  
	 }
}

// Protected access modifiers
class ProtectAccessSpecifier {
	protected void demo()  { 
		 System.out.println("You are using protected access specifier"); 
		}
}


public class AccessModifiers {
	public  static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
	    obj.displaying(165); 
	    obj.displaying(121.345667f);
	    
	    // Error -> this method is private it can't visible outside the another class, we can access with in a class.
	     PrivAccessSpecifier obj1 = new PrivAccessSpecifier();
	     // obj1.display();
	     System.out.println("Error: Unresolved compilation problem:The method display() from the type PrivAccessSpecifier is not visible");
	    
	    PubliAccessSpecifier obj2 = new PubliAccessSpecifier();
	    obj2.sample();
	    
	    ProtectAccessSpecifier obj3 = new ProtectAccessSpecifier();
	    obj3.demo();
	    
	}
}

