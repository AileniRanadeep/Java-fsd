package com.map;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PhoneBook {
    public static void main(String[] args) {
        // Create a map to store phone book entries
        Map<String, String> phoneBook = new HashMap<>();
        
        // Add some initial entries to the phone book
        phoneBook.put("Remo DEo", "9834567224");
        phoneBook.put("Jonny Smith", "9876154321");
        
        // Create a scanner to read user input
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("=== Phone Book ===");
            System.out.println("1. Look up a phone number");
            System.out.println("2. Add a new entry");
            System.out.println("3. Remove an entry");
            System.out.println("4. Quit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            
            if (choice == 1) {
                System.out.print("Enter the name to look up: ");
                scanner.nextLine(); // Consume the newline character
                String name = scanner.nextLine();
                
                String phoneNumber = phoneBook.get(name);
                
                if (phoneNumber != null) {
                    System.out.println("Phone number: " + phoneNumber);
                } else {
                    System.out.println("Entry not found!");
                }
            } else if (choice == 2) {
                System.out.print("Enter the name: ");
                scanner.nextLine(); // Consume the newline character
                String name = scanner.nextLine();
                
                System.out.print("Enter the phone number: ");
                String phoneNumber = scanner.nextLine();
                
                phoneBook.put(name, phoneNumber);
                
                System.out.println("Entry added successfully!");
            } else if (choice == 3) {
                System.out.print("Enter the name to remove: ");
                scanner.nextLine(); // Consume the newline character
                String name = scanner.nextLine();
                
                String phoneNumber = phoneBook.remove(name);
                
                if (phoneNumber != null) {
                    System.out.println("Entry removed successfully!");
                } else {
                    System.out.println("Entry not found!");
                }
            } else if (choice == 4) {
                System.out.println("Goodbye!");
                break;
            } else {
                System.out.println("Invalid choice!");
            }
        }
    }
  }
       