package com.map;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
        // Create a new map
        Map<String, Integer> grades = new HashMap<>();

        // Add key-value pairs to the map
        grades.put("ravi", 88);
        grades.put("Bobby", 75);
        grades.put("Charan", 85);

        // Access values using keys
        int raviGrade = grades.get("ravi");
        System.out.println("ravi grade: " +raviGrade);

        // Update a value
        grades.put("Bobby", 90);

        // Check if a key exists
        boolean hasCharlie = grades.containsKey("Charan");
        System.out.println("Does Charan exist? " + hasCharlie);

        // Iterate over the map
        for (Map.Entry<String, Integer> entry : grades.entrySet()) {
            String name = entry.getKey();
            int grade = entry.getValue();
            System.out.println(name + "'s grade: " + grade);
        }

        // Remove a key-value pair
        grades.remove("ravi");
        System.out.println("After removing ravi: " + grades);
    }
}












        
      