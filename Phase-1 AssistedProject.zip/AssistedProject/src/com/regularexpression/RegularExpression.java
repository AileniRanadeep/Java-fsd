package com.regularexpression;

import java.util.regex.*;

public class RegularExpression {

	public static void main(String[] args) {
		
		
		// To get all the all uppercase letters
		String pattern = "[A-Z]+";
		String check = "RegUlaR ExpResSioNs";
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(check);
		
		while (c.find())
	      	System.out.println( check.substring( c.start(), c.end() ) );
		
	}
}


