package com.ImplicitAndExplicit;

public class ImplicitAndExplicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Implicit
		// byte 🡪 short 🡪 int 🡪 long 🡪 float 🡪 double
		byte a = 30;
		short b = a ;
		System.out.println("a =  "+a);
		System.out.println("b = " +b);
		System.out.println("Implicit casting to byte to short: " +b);
		
		// Implicit
		int c = 6;
		float d =c;
		System.out.println("c =  " +c);
		System.out.println("d = " +d);
		System.out.println("Implicit casting to int to float: "+d);
		
		// Explicit
		//double 🡪 float 🡪 long 🡪 int 🡪 short 🡪 byte
		double e = 2445690889954d;
		//int f = e;  // Error -> Type mismatch: cannot convert from double to int
		int f = (int) e;
		System.out.println("e "+e);
		System.out.println("f "+f);

		System.out.println("Explicit casting to double to int: "+f);
		
		short g = 120;
		// byte h = g;		// error -> Type mismatch: cannot convert from short to byte
		byte h = (byte) g;
		System.out.println("g "+g);
		System.out.println("h "+h);

		System.out.println("Explicit casting to short to byte: "+g);
		

		
		
		
	}

}
