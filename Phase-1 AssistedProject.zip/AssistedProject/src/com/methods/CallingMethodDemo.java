package com.methods;

class  Facebook {
	void login(String EmailID, String Password) {
		System.out.println("Login using userID and password");
	}
	void login(long Contactnumber, String password) {
		System.out.println("Login through a Contactnumber and password");
	}
}
public class CallingMethodDemo {
	public static void main(String args[]) {
		Facebook log = new Facebook();
		log.login("javasample@gmsil.com", "hello");
		log.login(8980197788l, "hello");
	}

}


