package com.methods;

public class ReturnTypeMethod {
	public static int incomelabs(double salary)
	{
		if(salary<=300000.00)
		{
			return 0;
		}
		else if(salary>=300000.00 && salary<=500000.00)
		{
			return 10;
		}
		else if (salary>=500000.00 && salary<=800000.00)
		{
			return 15;
		}
		else 
		{
			return 20;
		}
	}
	public static void main(String[] args) 
	{
		System.out.println("this is user.......");
		int percentage= incomelabs(5641.58);
		System.out.println("percentage for your salary is:"+percentage);
	}
}

