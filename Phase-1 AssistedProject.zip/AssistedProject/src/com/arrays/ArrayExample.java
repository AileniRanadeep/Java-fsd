package com.arrays;

public class ArrayExample {
		public static void main(String[] args) {

				int a[];		// declation 
				int x[]= {10,20,30,40,50,60,90,120,45,23,43,13,56,90,100};
				System.out.println(x);		// display array address in hexa decimal format. 
				System.out.println("0 index postion "+x[0]);
				System.out.println("0 index postion "+x[3]);
				System.out.println("---------------------------");
				
				int m[]=new int[10];	// dynamic memory
				m[0]=100;
				m[1]=101;
				System.out.println("0 position value "+m[0]);
				System.out.println("1 position value "+m[1]);
				System.out.println("5 position value "+m[5]);
				System.out.println("9 position value "+m[9]);
			
				System.out.println("---------------------------");
				
				
				System.out.println("Retrieve array value using for loop");
				System.out.println("Size of array "+x.length);  // size of array 
				for(int i=0;i<x.length;i++) {
					System.out.println("Value of array "+x[i]);
				}
				System.out.println("---------------------------");
				System.out.println("Retrieve array value for enhaced loop");
				for(int n : x) {
					System.out.println("Value of array "+n);
				}
				System.out.println("---------------------------");
				System.out.println("Retrieve array value for enhaced loop");
				for(int n : m) {
					System.out.println("Value of array "+n);
				}
				}

		}
