package com.constructor;


public class Constructor {
	//Default(no-argument)constructor
	public Constructor() {
		System.out.println("Default constructor called.");
	}
	
	
    //Parameterized constructor
	public Constructor(String Message) {
	    System.out.println ("Parameterized constructor called with message:" +  Message);
	}
	public static void main(String[] args) {
		//Creating an object using the default constructor
		Constructor dc= new Constructor();
		
		//Creating an object using the parameterized constructor
		Constructor dc1 = new Constructor("Random Message");
	}

}

