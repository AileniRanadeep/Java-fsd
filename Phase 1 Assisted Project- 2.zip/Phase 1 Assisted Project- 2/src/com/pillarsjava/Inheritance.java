package com.pillarsjava;

import java.util.Scanner;


class Animal {
	  String name;
	  String color;

	 public void speak() {
	     System.out.println("The animal is making a sound.");
	 }
}

class Dog extends Animal {
    String name;
	String breed; 
    public void speak() {
        System.out.println("Woof! Woof!");
    }
    public void fetch() {
        System.out.println("The dog is fetching a ball.");
    }

}

public class Inheritance {
		
		public static void main(String[] args) {
	        Animal animal = new Animal();
	        Scanner sc = new Scanner(System.in);
	        
			System.out.println("Enter Animal Type :");
			animal.name=sc.nextLine();
			System.out.println("Enter color of Animal :");
			animal.color = sc.nextLine();
			System.out.println("Enter Animal Type : " +animal.name);
			System.out.println("Enter color of Animal : " +animal.color);
			
	        animal.speak();  // Output: The animal is making a sound.

	       Dog dog = new Dog();
	       dog.name = "Tommy";
	       dog.breed = "Labrador";
	       dog.speak(); // Output:Woof! Woof!
	       dog.fetch();  //Output: The dog is fetching a ball
	       System.out.println("the Dog Name is : "+dog.name); // Output:Tommy
	       System.out.println("the Dog breed is : "+dog.breed); // Output:Labrador
	       
	   }
}


