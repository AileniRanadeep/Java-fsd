package com.pillarsjava;

//AadharCard class
class AadharCard {
	private String name;
	private String aadharNumber;
	private String address;
	private String phoneNumber;

	public AadharCard(String name, String aadharNumber, String address, String phoneNumber) {
		this.name = name;
		this.aadharNumber = aadharNumber;
		this.address = address;
		this.phoneNumber = phoneNumber;
	}

	// Getter methods
	public String getName() {
		return name;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public String getAddress() {
		return address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

 // Setter methods
	public void setName(String name) {
		this.name = name;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public void setAddress(String address) {
		this.address = address;
		}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

 // Display method
	public void displayDetails() {
		System.out.println("Name: " + name);
		System.out.println("Aadhar Number: " + aadharNumber);
		System.out.println("Address: " + address);
		System.out.println("Phone Number: " + phoneNumber);
	}
}

//Main class
public class EncapsulationDemo {
	public static void main(String[] args) {
		AadharCard aadharCard = new AadharCard("Rama Krishna", "8027 1278 4151 9340", "H N0:1-23/A Mainroad School", "8027101278 ");
		aadharCard.displayDetails();

		System.out.println("\nUpdating Aadhar Card details...");

		aadharCard.setName("jonny Smith");
		aadharCard.setAadharNumber("6780 4509 1838 0221");
		aadharCard.setAddress("H N0:4-90/A/2 Temple Road");
		aadharCard.setPhoneNumber("9905982056");

		System.out.println("\nUpdated Aadhar Card details:");
		aadharCard.displayDetails();
}
}
