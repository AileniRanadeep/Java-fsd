package com.pillarsjava;


class Zara {
	void buying_clothes() {
		System.out.println("pay the original price and by the clothes");
	}
}

class Myntra extends Zara {
	void buying_clothes () {
		System.out.println("buy with an 30% offer and win the vouchers");
	}
}

class Ajio extends Zara {
	void buying_clothes () {
		System.out.println("buy with an 35% offer and win the gifts based on the your price purchase");
	}
}

class sample {
	void shopping(Zara ref)  {
		ref.buying_clothes();
	}
}
public class Polymorphism {
	public static void main(String[] args) {
		sample user1 = new sample();
		user1.shopping(new Ajio());
		user1.shopping(new Myntra());
	}

}
