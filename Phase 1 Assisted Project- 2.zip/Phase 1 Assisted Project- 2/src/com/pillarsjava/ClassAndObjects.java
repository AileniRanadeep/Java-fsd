package com.pillarsjava;

// Define the Person class
class Person {
	String name;
	int age;
	
	// Constructor for the Person class
	Person(String name, int age) {
	this.name = name;
	this.age = age;
	}

	// Method to display the details of a person
	void displayDetails() {
	System.out.println("Name: " + name);
	System.out.println("Age: " + age);
	}
}

	// Define the Employee class that extends the Person class
class Employee extends Person {
	String designation;
	int employeeID;

	// Constructor for the Employee class
	Employee(String name, int age, String designation, int employeeID) {
		super(name, age);
		this.designation = designation;
		this.employeeID = employeeID;
	}

	    // Method to display the details of an employee
	void displayEmployeeDetails() {
	displayDetails();
	System.out.println("Designation: " + designation);
	System.out.println("Employee ID: " + employeeID);
	}
}

	// Main class
public class ClassAndObjects {
	public static void main(String[] args) {
		// Create an object of the Person class
		Person person = new Person("karthik", 26);
		person.displayDetails();

		// Create an object of the Employee class
		Employee employee = new Employee("Ramesh", 34, "Software Engineer", 12345);
	    employee.displayEmployeeDetails();
	        
	    }
}


