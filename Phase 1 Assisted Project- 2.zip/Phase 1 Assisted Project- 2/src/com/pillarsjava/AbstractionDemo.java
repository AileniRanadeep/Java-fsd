package com.pillarsjava;


//Abstract class online payment method
abstract class PaymentMethod {
	abstract void makePayment(double amount);
	}

	//Concrete class representing Google Pay payment method
	class GooglePay extends PaymentMethod {
		private String phoneNumber;
		private String pin;

		public GooglePay(String phoneNumber, String pin) {
			this.phoneNumber = phoneNumber;
			this.pin = pin;
		}

		@Override
 		void makePayment(double amount) {
			System.out.println("Processing Google Pay payment of amount: " + amount);
			// Logic to perform the Google Pay payment
			System.out.println("Payment successful!");
		}
	}

//Concrete class representing PhonePe payment method
class PhonePe extends PaymentMethod {
	private String phoneNumber;
	private String UPI;
	public PhonePe(String phoneNumber, String UPI) {
		this.phoneNumber = phoneNumber;
		this.UPI = UPI;
	}

	@Override
	void makePayment(double amount) {
		System.out.println("Processing PhonePe payment of amount: " + amount);
    	// Logic to perform the PhonePe payment
		System.out.println("Payment successful!");
	}
}


public class AbstractionDemo {
	public static void main(String[] args) {
	

     //  PaymentMethod abstraction to make a Google Pay payment
		PaymentMethod payment1 = new GooglePay("9876543210", "1234");
		double amount = 10000.00;
		payment1.makePayment(amount);

		System.out.println();

     //  PaymentMethod abstraction to make a PhonePe payment
		PaymentMethod payment2 = new PhonePe("9876543210", "phonepe@upi");
		 amount = 250000.00;
		payment2.makePayment(amount);

	}
}