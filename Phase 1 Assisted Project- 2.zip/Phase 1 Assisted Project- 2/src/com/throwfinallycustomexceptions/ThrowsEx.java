package com.throwfinallycustomexceptions;

public class ThrowsEx {
        void Division() throws ArithmeticException
        {
            int num1=45,num2=0,result;
            result = num1 / num2;
            System.out.print("\n\tThe result is : " + result);
        }
public static void main(String[] args) {
	ThrowsEx T = new ThrowsEx();
	try
	{
		T.Division();
	}
	catch(ArithmeticException Ex)
	{
		System.out.print("\n \tError : " + Ex.getMessage());
	}
	System.out.print("\n \tEnd of program.");
	}
}
