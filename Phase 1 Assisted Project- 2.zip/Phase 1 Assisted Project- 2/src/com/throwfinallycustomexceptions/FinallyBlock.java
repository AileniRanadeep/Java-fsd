 package com.throwfinallycustomexceptions;

public class FinallyBlock {

	public static void main(String[] args) {
		
        int num1=15,num2=0,results=0;
        try
        {
        	results = num1 / num2;
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\n\tError : " + Ex.getMessage());
        }
        finally
        {
            System.out.print("\n\tThe result is : " + results);
        }

	}

}
