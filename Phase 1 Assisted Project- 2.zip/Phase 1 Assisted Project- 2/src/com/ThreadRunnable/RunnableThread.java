 package com.ThreadRunnable;

//Creating a thread by extending the Thread class
class MyThread extends Thread {
	@Override
	public void run() {
		System.out.println("Thread created by extending Thread class.");
		for (int i = 0; i < 6; i++) {
			System.out.println("Thread: " + i);
	        
		}
	}
	}

//Creating a thread by implementing the Runnable interface
class MyRunnable implements Runnable {
	@Override
	public void run() {
		System.out.println("Thread created by implementing Runnable interface.");
		for (int i = 0; i < 3; i++) {
			System.out.println("Thread: " + i); 
		}
	}
}

public class RunnableThread {
	public static void main(String[] args) {
		// Creating and starting a thread using the MyThread class
		MyThread thread1 = new MyThread();
		thread1.start();

		// Creating and starting a thread using the MyRunnable class
		MyRunnable runnable = new MyRunnable();
		Thread thread2 = new Thread(runnable);
		thread2.start();
	}
}



