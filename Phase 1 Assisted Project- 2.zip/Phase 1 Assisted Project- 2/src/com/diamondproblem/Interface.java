package com.diamondproblem;


interface Vehicle {
	void manufacture();
	void sell();

	default void displayInfo() {
		System.out.println("This is a vehicle.");
	}
}


interface Car extends Vehicle {
	void drive();

	default void displayInfo() {
		System.out.println("This is a car.");
	}
}



class Toyota implements Car {
	@Override
 	public void manufacture() {
	 	System.out.println("Manufacturing car.");
 	}

 	@Override
 	public void sell() {
 		System.out.println("Selling Toyota car.");
 	}

 	@Override
 	public void drive() {
 		System.out.println("Driving the Toyota car.");
 	}
}



public class Interface {
	public static void main(String[] args) {
			
		Car car = new Toyota();
     
			car.manufacture();
			car.drive();
			car.sell();
			car.displayInfo();

	}
}