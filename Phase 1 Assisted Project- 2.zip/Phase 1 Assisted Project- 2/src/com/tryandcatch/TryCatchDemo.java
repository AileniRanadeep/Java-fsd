package com.tryandcatch;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryCatchDemo {
	public static void main(String[] args) {
		System.out.println("The start the game......");
		
		try {
		Scanner inp = new Scanner(System.in);
		System.out.println("Enter first number:");
		int num1 = inp.nextInt();
		
		System.out.println("Enter Second number:");
		int num2 = inp.nextInt();
		
			int div = num1/num2; //risky code
			System.out.println("the resultant value:" +div);
		}
		catch(ArithmeticException e) 
		{
			System.out.println("Arithmetic Exception handled");
		}
		catch(InputMismatchException e) // it use for if user enter a any character, it result in a miss match of input
		{ 
			System.out.println("Input mismatch Exception handled");
		}
}
}
