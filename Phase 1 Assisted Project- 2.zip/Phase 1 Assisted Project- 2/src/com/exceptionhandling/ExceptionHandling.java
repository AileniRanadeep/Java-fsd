package com.exceptionhandling;

public class ExceptionHandling {

	public static void main(String[] args) {
		try {
			String[] strings = {"Hello", "World"};
			System.out.println(strings[2]);
		 	} 
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Caught an exception: " + e.getMessage());
			System.out.println("Caught an exception: " + e.toString());
		} 
		finally {
			System.out.println("This block is always executed, regardless of whether an exception was thrown or not.");
		}
	}
}
	

