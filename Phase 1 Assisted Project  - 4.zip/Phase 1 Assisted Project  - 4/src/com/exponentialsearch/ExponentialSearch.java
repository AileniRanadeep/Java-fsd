package com.exponentialsearch;


import java.util.Arrays;

public class ExponentialSearch {
	public static void main(String[] args) {
		int num[] = {1, 2,  3,  4,  5,  6,  7,  8,  21,  34, 45,  91, 120, 130, 456, 564};
		//index		 0	1	2	3	4	5	6	7	8	 9	 10	  11   12	13	14	  15
		int searchnum = 21;
			
		int index = exponentialSearch(num, searchnum);

		System.out.println(searchnum + " is found at index: " + index + " position");		
			
	}

private static int exponentialSearch(int[] arr, int i) {
	int start_num = 0;
			
	if(arr[start_num] == i)
		return start_num;
	start_num =1;
	while(start_num < arr.length && arr[start_num] <= i) {
		start_num*=2;
	}
		return Arrays.binarySearch(arr, start_num/2, Math.min(start_num, arr.length), i);
	}
}
