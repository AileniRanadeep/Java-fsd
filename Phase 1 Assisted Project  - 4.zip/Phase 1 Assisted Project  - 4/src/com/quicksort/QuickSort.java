package com.quicksort;

import java.util.Arrays;

public class QuickSort {
	  static int partition(int arr[], int low, int high) {
	    int pivot = arr[high];
	    int i = (low - 1);
	    for (int j = low; j < high; j++) {
	      if (arr[j] <= pivot) {
	        i++;
	        int temp = arr[i];
	        arr[i] = arr[j];
	        arr[j] = temp;
	      }
	    }
	    int temp = arr[i + 1];
	    arr[i + 1] = arr[high];
	    arr[high] = temp;

	    return (i + 1);
	  }

	  static void quickSort(int arr[], int low, int high) {
	    if (low < high) {
	      int partition = partition(arr, low, high);
	      quickSort(arr, low, partition - 1);
	      quickSort(arr, partition + 1, high);
	    }
	  }

	  public static void main(String args[]) {

	    int[] data = { 8, 7, 2, 1, 9, 6, 0};
	    System.out.println("Unsorted Array");
	    System.out.println(Arrays.toString(data));

	    int size = data.length;

	    QuickSort.quickSort(data, 0, size - 1);

	    System.out.println("Sorted Array in Ascending Order ");
	    System.out.println(Arrays.toString(data));
	 }
}

