package com.binaryserach;

class BinarySearch {
	  int binarySearch(int arr[], int key, int low, int high) {

	    // Repeat until the pointers low and high meet each other
	    while (low <= high) {
	    	
	      int mid = (low + high) / 2;

	      if (arr[mid] == key)
	        return mid;

	      else if (key > arr[mid])
	        low = mid + 1;

	      else
	        high = mid - 1;
	    }

	    return -1;
	  }

public static void main(String args[]) {
	
	BinarySearch obj = new BinarySearch();
	
		int arr[] = { 13, 24, 33, 41, 57, 66, 72 };
		int n = arr.length;
		int key = 72;
		int result = obj.binarySearch(arr, key, 0, n - 1); // binary search( array, search element, low, high)
		if (result == -1)
			System.out.println("Your Serach Element is " + key + " not found at any index");
		else
			System.out.println("Your Serach  Element " + key +" is found at index : " + result +" position");
	}
}